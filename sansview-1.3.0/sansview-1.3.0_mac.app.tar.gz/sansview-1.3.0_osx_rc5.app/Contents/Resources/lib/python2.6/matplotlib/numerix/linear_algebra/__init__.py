try:
    from numpy.oldnumeric.linear_algebra import *
except ImportError:
    from numpy.linalg.old import *
