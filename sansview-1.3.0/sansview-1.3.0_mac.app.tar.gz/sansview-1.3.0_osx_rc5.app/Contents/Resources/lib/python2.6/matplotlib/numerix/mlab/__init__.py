try:
   from numpy.oldnumeric.mlab import *
except ImportError:
   from numpy.lib.mlab import *

amin = min
amax = max
