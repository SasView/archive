try:
    from numpy.oldnumeric.random_array import *
except ImportError:
    from numpy.random import *
