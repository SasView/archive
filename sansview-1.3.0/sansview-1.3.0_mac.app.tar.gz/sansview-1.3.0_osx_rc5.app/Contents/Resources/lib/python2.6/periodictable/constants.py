# This program is public domain

avogadro_number = 6.02214179e23 #(30) mol-1
plancks_constant = 4.13566733e-15 #(10) eV s
speed_of_light = 299792458 # m/s (exact)
electron_radius = 2.8179402894e-15 #(58) m
