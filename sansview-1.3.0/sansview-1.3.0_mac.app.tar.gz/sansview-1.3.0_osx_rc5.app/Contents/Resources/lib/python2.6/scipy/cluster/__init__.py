#
# spatial - Distances
#

from info import __doc__

__all__ = ['vq', 'hierarchy']

import vq, hierarchy

from numpy.testing import Tester
test = Tester().test
