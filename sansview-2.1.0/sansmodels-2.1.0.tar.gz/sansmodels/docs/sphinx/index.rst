.. sansmodels documentation master file, created by
   sphinx-quickstart on Fri Jun 04 15:06:28 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to sansmodels's documentation!
======================================

Contents:

.. toctree::
   :maxdepth: 2

   api/index.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

