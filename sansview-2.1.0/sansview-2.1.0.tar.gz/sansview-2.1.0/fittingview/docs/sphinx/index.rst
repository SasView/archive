.. sansview documentation master file, created by
   sphinx-quickstart on Mon Jun 07 09:27:34 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to sansview's documentation!
====================================

Contents:

.. toctree::
   :maxdepth: 2
	
   api/perspectives/fitting/index.rst
 	

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

