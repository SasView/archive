PLUGIN_ID = "P(r) plug-in 1.0"
from pr import *