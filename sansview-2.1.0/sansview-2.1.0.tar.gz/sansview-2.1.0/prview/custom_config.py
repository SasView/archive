#Application appearance custom configuration
