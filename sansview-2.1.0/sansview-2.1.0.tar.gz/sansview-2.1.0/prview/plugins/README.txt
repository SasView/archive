The "plugins" folder is meant for users to add models and readers 
that can be loaded automatically by the application.
See documentation for details.