.. calculator documentation master file, created by
   sphinx-quickstart on Thu May 27 09:12:00 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Calculator
======================================
Calculator is a package that contains other sub-modules necessary for small computations. These sub-modules
may be independant of each other, but there are used as ``tools`` for sansview application. The calculator package
currently contains the following sub-modules:

* :ref:`sans.calculator.index`

.. htmlonly::

   :Release: |version|
   :Date:    |today|

   
.. toctree::
   :maxdepth: 2

   api/index.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

