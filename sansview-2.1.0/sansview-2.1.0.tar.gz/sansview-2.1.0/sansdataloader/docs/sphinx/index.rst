.. DataLoader documentation master file, created by
   sphinx-quickstart on Tue Jun 01 12:50:32 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to DataLoader's documentation!
======================================

Contents:

.. toctree::
   :maxdepth: 2
   
   api/index.rst
   api/readers/index.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

