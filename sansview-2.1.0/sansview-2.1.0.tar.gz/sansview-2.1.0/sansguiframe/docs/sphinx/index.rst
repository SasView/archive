.. guiframe documentation master file, created by
   sphinx-quickstart on Thu Jun 03 11:04:06 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to guiframe's documentation!
====================================

Contents:

.. toctree::
   :maxdepth: 2

   api/index.rst
   api/local_perspectives/plotting/index.rst
   api/local_perspectives/data_loader/index.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

