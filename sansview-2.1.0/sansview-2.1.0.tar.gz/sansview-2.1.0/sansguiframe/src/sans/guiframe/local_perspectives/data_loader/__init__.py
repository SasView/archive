PLUGIN_ID = "DataLoader plug-in 1.0"
from sans.guiframe.local_perspectives.data_loader import *