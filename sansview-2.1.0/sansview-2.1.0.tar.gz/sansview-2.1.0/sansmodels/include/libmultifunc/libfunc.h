#if !defined(o_h)
#define libfunc_h

int factorial(int i);

double Si(double x);

double sinc(double x);

double gamln(double x);

#endif
