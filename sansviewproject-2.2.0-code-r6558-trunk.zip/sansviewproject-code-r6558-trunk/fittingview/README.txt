################################################################################
#This software was developed by the University of Tennessee as part of the
#Distributed Data Analysis of Neutron Scattering Experiments (DANSE)
#project funded by the US National Science Foundation. 
#
#See the license text in license.txt
#
#copyright 2008, University of Tennessee
################################################################################


Fittingview is responsible for creating and maintaining the
graphical fitting perspective. It uses the sans.guiframe, sans.dataloader,
and sans.models packages.

It provides features such as fitting 1D/2D data  and computing theory.