Plottools is a package responsible of plotting 1 and 2D data.
 It is a small wrapper between wx and matplotlib packages. It provides a panel
 for which all its options are available through a context menu or a tool bar.