/*
 *  cpoly.h
 *  TwoYukawa
 *
 *  Created by Marcus Hennig on 5/8/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */
int cpoly( const double *opr, const double *opi, int degree, double *zeror, double *zeroi ); 