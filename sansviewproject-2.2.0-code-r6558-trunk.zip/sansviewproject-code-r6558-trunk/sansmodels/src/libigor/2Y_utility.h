/*
 *  utility.h
 *  twoyukawa
 *
 *  Created by Marcus Hennig on 5/13/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */
#include <math.h>

double chop( double x );