/*
 *  StandardHeaders.h
 *  SANSAnalysis
 *
 *  Created by Andrew Jackson on 4/23/07.
 *  Copyright 2007 __MyCompanyName__. All rights reserved.
 *
 */

#include <math.h>
#include <ctype.h>

#include <stdlib.h>
#include <stdio.h>

#ifdef _WIN32
#include <float.h>
#include "winFuncs.h"
#endif