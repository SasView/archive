.. SasView documentation master file, created by
   sphinx-quickstart on Wed Aug 28 14:59:44 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

SasView Documentation
=====================

.. toctree::
   :maxdepth: 1

   User Documentation <user/user>

   Developer Documentation <dev/dev>