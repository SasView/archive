PARK optimization

Release 1.2.1  2010-04-28
* fix log(0) handling
* update number(uncertainty) handling

