PLUGIN_ID = "DataLoader plug-in 1.0"
from sas.guiframe.local_perspectives.data_loader import *