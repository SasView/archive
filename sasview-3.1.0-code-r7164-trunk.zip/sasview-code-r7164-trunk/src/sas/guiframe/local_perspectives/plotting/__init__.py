PLUGIN_ID = "Plotting plug-in 1.0"
from sas.guiframe.local_perspectives.plotting import *
