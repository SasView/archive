import config
from PlotPanel import PlotPanel
from plottables import Data1D, Theory1D
