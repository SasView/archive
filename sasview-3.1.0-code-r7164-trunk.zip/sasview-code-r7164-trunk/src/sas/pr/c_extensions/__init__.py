"""
    C extensions to provide the P(r) inversion computations.
"""
