This Tutorial.pdf is what appears when you click on 'Tutorial' under 'Help'
in the menu bar.

The source files are in: /SasViewLocalTrunk/docs/sasview